import React from 'react';
import GoogleDocumentViewer from './GoogleDocumentViewer';

function App() {
  return (
    <div className="App">
      <GoogleDocumentViewer />
    </div>
  );
}

export default App;
